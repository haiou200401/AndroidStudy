package com.studyapi.calc;

import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.studyapi.BaseActivity;
import com.studyapi.R;

public class PerformanceActivity extends BaseActivity implements View.OnClickListener {
    final String TAG = "gqg:PerformanceActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_performance);

        findViewById(R.id.id_performance_test_start).setOnClickListener(this);
    }

    private void calcStart() {
        String str = "";
        for(int i=0; i<1000*1; i++) {
            str += String.valueOf(i);
        }
        Log.e(TAG, str);
        Log.e(TAG, "end out!");
    }

    @Override
    public void onClick(View v) {
        Debug.startMethodTracing("gqg_debug");
        calcStart();
        Debug.stopMethodTracing();
        //Debug.getLoadedClassCount();
    }
}
