#FileManager
Android filemanager provides a user interface to manage files and folders. Here we develop a simple filemanager demo how to manage your internal and external files and folder on your android devices.
##Overview
This article will take a comprehensive look at working with files and folders.It provides a simple way to present a scrolling list of rows that can either files or folders.

##FileManager Usage
 * listing of all file from your internal and external memory
 * create folders or files
 * delete folders or files
 * edit your txt file 
 * play your audio,video files
 * open image files

![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/a.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/0.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/1.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/2.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/3.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/4.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/5.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/6.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/7.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/8.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/9.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/10.jpg)
![alt tag](https://github.com/satishtamada/FileManager/blob/master/ScreenShots/11.jpg)